package secrets

import (
	"bytes"
	"encoding/json"
	"filippo.io/age"
)

// RecipientStore can only encrypt to the CA's public recipient. API assembly
// never needs the CA identity or a decryption capability for EAB credentials.
type RecipientStore struct{ recipient *age.X25519Recipient }

func NewRecipient(public string) (*RecipientStore, error) {
	r, e := age.ParseX25519Recipient(public)
	if e != nil {
		return nil, errSecret
	}
	return &RecipientStore{r}, nil
}
func (s *RecipientStore) Recipient() string { return s.recipient.String() }
func (s *Store) Recipient() string          { return s.identity.Recipient().String() }
func (s *RecipientStore) Seal(label string, plain []byte) ([]byte, error) {
	if s == nil || s.recipient == nil || label == "" || len(label) > 1024 || len(plain) > maxPayload {
		return nil, errSecret
	}
	body, e := json.Marshal(payload{1, label, plain})
	if e != nil {
		return nil, errSecret
	}
	defer clear(body)
	var out bytes.Buffer
	w, e := age.Encrypt(&out, s.recipient)
	if e != nil {
		return nil, errSecret
	}
	if _, e = w.Write(body); e != nil {
		return nil, errSecret
	}
	if e = w.Close(); e != nil {
		return nil, errSecret
	}
	return out.Bytes(), nil
}
