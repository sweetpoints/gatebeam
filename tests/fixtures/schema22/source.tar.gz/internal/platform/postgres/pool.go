package postgres

import (
	"context"
	"errors"
	"gatebeam/db/migrations"
	"gatebeam/internal/platform/bootstrap"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgx/v5/stdlib"
	"github.com/pressly/goose/v3"
	"io"
	"os"
	"strings"
	"time"
)

func Open(ctx context.Context, cfg bootstrap.Config) (*pgxpool.Pool, error) {
	f, e := os.Open(cfg.DatabaseFile)
	if e != nil {
		return nil, errors.New("database secret unavailable")
	}
	defer f.Close()
	info, e := f.Stat()
	if e != nil || !info.Mode().IsRegular() {
		return nil, errors.New("database secret unavailable")
	}
	data, e := io.ReadAll(io.LimitReader(f, 65537))
	if e != nil || len(data) == 0 || len(data) > 65536 {
		return nil, errors.New("database secret unavailable")
	}
	pc, e := pgxpool.ParseConfig(strings.TrimSpace(string(data)))
	if e != nil {
		return nil, errors.New("invalid database configuration")
	}
	pc.MaxConns = 8
	pc.MinConns = 0
	pc.ConnConfig.ConnectTimeout = 5 * time.Second
	p, e := pgxpool.NewWithConfig(ctx, pc)
	if e != nil {
		return nil, errors.New("database unavailable")
	}
	c, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if e = p.Ping(c); e != nil {
		p.Close()
		return nil, errors.New("database unavailable")
	}
	return p, nil
}
func Migrate(ctx context.Context, p *pgxpool.Pool) error {
	db := stdlib.OpenDBFromPool(p)
	defer db.Close()
	provider, e := goose.NewProvider(goose.DialectPostgres, db, migrations.Files, goose.WithDisableGlobalRegistry(true))
	if e != nil {
		return errors.New("migration initialization failed")
	}
	if _, e = provider.Up(ctx); e != nil {
		return errors.New("migration failed")
	}
	return nil
}
