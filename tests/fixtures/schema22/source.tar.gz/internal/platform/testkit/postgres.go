// Package testkit supplies mandatory real PostgreSQL fixtures; missing DB is fatal.
package testkit

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"gatebeam/internal/platform/postgres"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"os"
	"testing"
	"time"
)

func Postgres(t testing.TB) *pgxpool.Pool {
	t.Helper()
	dsn := os.Getenv("GATEBEAM_TEST_DATABASE_URL")
	if dsn == "" {
		t.Fatal("run scripts/check-db.sh: PostgreSQL DSN required")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	cfg, e := pgxpool.ParseConfig(dsn)
	if e != nil {
		t.Fatal("invalid test DSN")
	}
	// Each fixture owns an isolated schema, so -p 2 packages cannot truncate
	// one another's jobs/audit/authentication data. Names are generated locally.
	var nonce [12]byte
	if _, e := rand.Read(nonce[:]); e != nil {
		t.Fatal("fixture name generation failed")
	}
	schema := "test_" + hex.EncodeToString(nonce[:])
	admin, e := pgx.Connect(ctx, dsn)
	if e != nil {
		t.Fatal("fixture database unavailable")
	}
	if _, e = admin.Exec(ctx, "CREATE SCHEMA "+pgx.Identifier{schema}.Sanitize()); e != nil {
		admin.Close(ctx)
		t.Fatal("fixture schema unavailable")
	}
	admin.Close(ctx)
	t.Cleanup(func() {
		c, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		admin, e := pgx.Connect(c, dsn)
		if e != nil {
			t.Error("fixture cleanup database unavailable")
			return
		}
		defer admin.Close(c)
		if _, e = admin.Exec(c, "DROP SCHEMA "+pgx.Identifier{schema}.Sanitize()+" CASCADE"); e != nil {
			t.Error("fixture cleanup failed")
		}
	})
	cfg.ConnConfig.RuntimeParams["search_path"] = schema
	cfg.MaxConns = 8
	p, e := pgxpool.NewWithConfig(ctx, cfg)
	if e != nil {
		t.Fatal("test database unavailable")
	}
	t.Cleanup(p.Close)
	if e = postgres.Migrate(ctx, p); e != nil {
		t.Fatal(e)
	}
	var version int
	if e = p.QueryRow(ctx, "SELECT current_setting('server_version_num')::integer").Scan(&version); e != nil || version < 180000 || version >= 190000 {
		t.Fatal("PostgreSQL 18 required")
	}
	return p
}
