package queryipc

import (
	"context"
	"errors"
	"gatebeam/internal/modules/observability/application/query"
	"gatebeam/internal/modules/observability/domain"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type blocked struct {
	started  chan struct{}
	finished chan struct{}
}

func (b blocked) Execute(ctx context.Context, _ query.Filter, _ []domain.Object) ([]domain.QueryRow, error) {
	close(b.started)
	<-ctx.Done()
	close(b.finished)
	return nil, ctx.Err()
}
func TestSocketIsolationBodyWhitelistAndCancel(t *testing.T) {
	dir, e := os.MkdirTemp("", "q-")
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { os.RemoveAll(dir) })
	socket := filepath.Join(dir, "query.sock")
	ctx, stop := context.WithCancel(t.Context())
	defer stop()
	b := blocked{make(chan struct{}), make(chan struct{})}
	done := make(chan error, 1)
	go func() { done <- Serve(ctx, socket, b) }()
	for i := 0; i < 100; i++ {
		if _, e := os.Stat(socket); e == nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	st, e := os.Stat(socket)
	if e != nil || st.Mode().Perm() != 0600 {
		t.Fatal("socket permissions", e)
	}
	client := &http.Client{Transport: &http.Transport{DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{}).DialContext(ctx, "unix", socket)
	}}, Timeout: time.Second}
	r, e := client.Post("http://query/execute", "application/json", strings.NewReader(`{"SQL":"INSTALL evil"}`))
	if e != nil {
		t.Fatal(e)
	}
	r.Body.Close()
	if r.StatusCode != 400 {
		t.Fatal("SQL accepted")
	}
	requestCtx, cancel := context.WithCancel(t.Context())
	requestDone := make(chan error, 1)
	go func() {
		_, e := NewClient(socket).Execute(requestCtx, query.Filter{SiteIDs: []string{"11111111-1111-4111-8111-111111111111"}, From: time.Now(), To: time.Now().Add(time.Hour)}, nil)
		requestDone <- e
	}()
	select {
	case <-b.started:
	case <-time.After(time.Second):
		t.Fatal("execution not started")
	}
	cancel()
	select {
	case <-b.finished:
	case <-time.After(time.Second):
		t.Fatal("HTTP cancel failed to reach executor")
	}
	if e = <-requestDone; !errors.Is(e, ErrUnavailable) {
		t.Fatal(e)
	}
	stop()
	if e = <-done; e != nil {
		t.Fatal(e)
	}
}
