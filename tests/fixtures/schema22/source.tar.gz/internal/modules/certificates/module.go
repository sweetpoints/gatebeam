// Package certificates assembles ordinary material capabilities, never CA signers.
package certificates

import (
	"crypto/x509"
	"encoding/json"
	"errors"
	"gatebeam/internal/modules/certificates/application"
	certcrypto "gatebeam/internal/modules/certificates/infrastructure/crypto"
	"gatebeam/internal/modules/certificates/infrastructure/lego"
	repo "gatebeam/internal/modules/certificates/infrastructure/postgres"
	"gatebeam/internal/modules/certificates/infrastructure/status"
	"gatebeam/internal/platform/audit"
	"gatebeam/internal/platform/jobs"
	"gatebeam/internal/platform/postgres"
	"gatebeam/internal/platform/secrets"
	"github.com/jackc/pgx/v5/pgxpool"
	"io"
	"net/http"
	"os"
)

func NewReader(p *pgxpool.Pool) *application.Service {
	return application.New(postgres.NewRunner(p), repo.NewPublicReader(), nil, certcrypto.Crypto{}, nil, nil, nil)
}

// NewEdge loads only the leaf identity. Provider recipient is public policy used
// to reject shared-key deployment mistakes, even when key file paths differ.
func NewEdge(p *pgxpool.Pool, graph application.Graph, leafIdentityFile, providerRecipient string) (*application.Service, error) {
	leaf, e := secrets.New(leafIdentityFile)
	if e != nil {
		return nil, e
	}
	provider, e := secrets.NewRecipient(providerRecipient)
	if e != nil {
		return nil, e
	}
	if leaf.Recipient() == provider.Recipient() {
		return nil, errors.New("leaf and provider encryption identities must differ")
	}
	return application.New(postgres.NewRunner(p), repo.NewMaterialReader(), graph, certcrypto.Crypto{}, leaf, nil, nil), nil
}

// sealOnly has no decryption capability; a worker needs only the leaf recipient.
type sealOnly struct{ application.SecretSealer }

func (sealOnly) Open(string, []byte) ([]byte, error) {
	return nil, errors.New("leaf decryption unavailable")
}
func NewWorker(p *pgxpool.Pool, graph application.Graph, providerIdentityFile, leafRecipient, webroot string, internal ...InternalACME) (*application.Service, error) {
	provider, e := secrets.New(providerIdentityFile)
	if e != nil {
		return nil, e
	}
	leaf, e := secrets.NewRecipient(leafRecipient)
	if e != nil {
		return nil, e
	}
	if provider.Recipient() == leaf.Recipient() {
		return nil, errors.New("leaf and provider encryption identities must differ")
	}
	client := &lego.Client{Secrets: provider, WebRoot: webroot, Journal: repo.NewChallenges(p)}
	if len(internal) > 0 && internal[0].Origin != "" {
		client.InternalOrigin = internal[0].Origin
		client.InternalHTTPClient = lego.HTTPClient()
		if internal[0].TransportTrustFile != "" {
			b, err := os.ReadFile(internal[0].TransportTrustFile)
			if err != nil {
				return nil, err
			}
			roots := x509.NewCertPool()
			if !roots.AppendCertsFromPEM(b) {
				return nil, errors.New("invalid internal ACME transport trust")
			}
			client.InternalHTTPClient.Transport.(*http.Transport).TLSClientConfig.RootCAs = roots
		}
	}
	return application.New(postgres.NewRunner(p), repo.New(), graph, certcrypto.Crypto{}, sealOnly{leaf}, client, jobs.New(p)), nil
}

// NewManagement receives two public recipients and cannot open either payload.
func NewManagement(p *pgxpool.Pool, security application.Security, graph application.Graph, leafRecipient, providerRecipient string) (*application.Management, *application.Service, error) {
	leaf, e := secrets.NewRecipient(leafRecipient)
	if e != nil {
		return nil, nil, e
	}
	provider, e := secrets.NewRecipient(providerRecipient)
	if e != nil {
		return nil, nil, e
	}
	if leaf.Recipient() == provider.Recipient() {
		return nil, nil, errors.New("leaf and provider encryption identities must differ")
	}
	management := application.NewManagement(security, graph, repo.New(), certcrypto.Crypto{}, leaf, provider, audit.New())
	service := application.New(postgres.NewRunner(p), repo.New(), graph, certcrypto.Crypto{}, nil, nil, jobs.New(p), management)
	return management, service, nil
}

// ConfigureStatus loads only operator-owned public trust/status policy. It does
// not load CA keys and never accepts request-supplied responder readiness.
func ConfigureStatus(service *application.Service, path string) error {
	if path == "" {
		return nil
	}
	file, e := os.Open(path)
	if e != nil {
		return e
	}
	defer file.Close()
	decoder := json.NewDecoder(io.LimitReader(file, 65537))
	decoder.DisallowUnknownFields()
	var profiles []status.Profile
	if e = decoder.Decode(&profiles); e != nil {
		return e
	}
	var extra any
	if decoder.Decode(&extra) != io.EOF {
		return errors.New("invalid status profiles")
	}
	source, e := status.New(profiles)
	if e != nil {
		return e
	}
	service.SetStatus(source)
	return nil
}

// InternalACME is operator bootstrap policy, never a management request.
type InternalACME struct{ Origin, TransportTrustFile string }

// NewQueries cannot select encrypted columns or load any private identity.
func NewQueries(security application.Security, graph application.Graph, bindings ...application.ActiveBindings) *application.Queries {
	return application.NewQueries(security, graph, repo.NewPublicReader(), bindings...)
}
