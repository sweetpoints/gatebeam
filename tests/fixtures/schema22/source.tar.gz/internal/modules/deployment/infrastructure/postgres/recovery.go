package postgres

import (
	"context"
	platform "gatebeam/internal/platform/postgres"
	"gatebeam/internal/platform/transaction"
	"github.com/jackc/pgx/v5"
)

type Recovery struct{}

func (Recovery) QuarantineRecovery(sc transaction.Scope) error {
	return platform.Use(sc, func(ctx context.Context, tx pgx.Tx) error {
		_, e := tx.Exec(ctx, `DELETE FROM deployment_execution_reports;DELETE FROM deployment_runtime;UPDATE deployment_releases SET state='failed',observed_version='',restored_version='';DELETE FROM deployment_target_runtime;DELETE FROM deployment_route_verifications;UPDATE deployment_generation SET generation=generation+1,dirty=false`)
		return e
	})
}
