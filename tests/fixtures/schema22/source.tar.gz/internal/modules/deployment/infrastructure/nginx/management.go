package nginx

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"strings"
)

func (b *builder) management(w *strings.Builder) error {
	m := b.runtime.Management
	if m == nil {
		return nil
	}
	if !validName(m.Domain) || !m.APIAddress.IsValid() || !m.APIAddress.Addr().IsPrivate() || m.APIAddress.Port() != 8080 || b.runtime.Now.IsZero() {
		return ErrInvalid
	}
	pair, e := tls.X509KeyPair(m.CertificatePEM, m.KeyPEM)
	if e != nil || len(pair.Certificate) == 0 {
		return ErrInvalid
	}
	leaf, e := x509.ParseCertificate(pair.Certificate[0])
	if e != nil {
		return ErrInvalid
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(m.TrustPEM) {
		return ErrInvalid
	}
	chain := x509.NewCertPool()
	for _, der := range pair.Certificate[1:] {
		c, e := x509.ParseCertificate(der)
		if e != nil {
			return ErrInvalid
		}
		chain.AddCert(c)
	}
	if _, e = leaf.Verify(x509.VerifyOptions{DNSName: m.Domain, Roots: roots, Intermediates: chain, CurrentTime: b.runtime.Now, KeyUsages: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}); e != nil {
		return ErrInvalid
	}
	b.files["materials/management.pem"] = append([]byte{}, m.CertificatePEM...)
	b.files["materials/management.key"] = append([]byte{}, m.KeyPEM...)
	fmt.Fprintf(w, `server {
 listen 8443 ssl;
 server_name %s;
 ssl_certificate materials/management.pem;
 ssl_certificate_key materials/management.key;
 ssl_protocols TLSv1.2 TLSv1.3;
 ssl_session_tickets off;
 if ($ssl_server_name != %s) { return 421; }
 if ($host != %s) { return 421; }
 set $edge_site 'management';
 location = /_gatebeam/ready { access_log off; default_type text/plain; return 200 'management-ready'; }
 location / {
  proxy_set_header Host %s;
  proxy_set_header X-Forwarded-Proto https;
  proxy_set_header X-Forwarded-For $remote_addr;
  proxy_set_header Forwarded '';
  proxy_connect_timeout 2s;
  proxy_read_timeout 15s;
  proxy_send_timeout 15s;
  proxy_next_upstream off;
  proxy_pass http://%s;
 }
}
`, m.Domain, m.Domain, m.Domain, m.Domain, m.APIAddress.String())
	return nil
}
