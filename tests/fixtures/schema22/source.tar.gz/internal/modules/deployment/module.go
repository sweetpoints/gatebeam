// Package deployment assembles only deployment-owned persistence.
package deployment

import (
	"gatebeam/internal/modules/deployment/application/release"
	"gatebeam/internal/modules/deployment/infrastructure/identifiers"
	"gatebeam/internal/modules/deployment/infrastructure/postgres"
)

func New() *release.Service { return release.New(postgres.New(), identifiers.Generator{}) }
