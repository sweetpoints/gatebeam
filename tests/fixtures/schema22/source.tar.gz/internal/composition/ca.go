package composition

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"gatebeam/internal/modules/pki"
	"gatebeam/internal/modules/pki/application"
	pkicrypto "gatebeam/internal/modules/pki/infrastructure/crypto"
	"gatebeam/internal/platform/bootstrap"
	"gatebeam/internal/platform/postgres"
	"net"
	"net/http"
	"net/netip"
	"time"
)

func importCA(ctx context.Context, cfg bootstrap.Config) error {
	return pki.ImportOffline(ctx, application.ImportCommand{SourceDirectory: cfg.CAImportDirectory, OnlineDirectory: cfg.CAOutputDirectory})
}
func bootstrapCA(ctx context.Context, cfg bootstrap.Config) error {
	if cfg.CAStatusOrigin == "" {
		return errors.New("offline ceremony requires the canonical HTTP status origin")
	}
	return pki.BootstrapOffline(ctx, application.BootstrapCommand{RootDirectory: cfg.OfflineRootDirectory, OnlineDirectory: cfg.CAOutputDirectory, RootName: cfg.CARootName, IntermediateName: cfg.CAIntermediateName, StatusOrigin: cfg.CAStatusOrigin})
}
func validateCAConfig(cfg bootstrap.Config) error {
	addr, e := netip.ParseAddrPort(cfg.CAListen)
	if e != nil || addr.Port() == 0 || (!addr.Addr().IsPrivate() && !addr.Addr().IsLoopback()) || cfg.CAHostname == "" || cfg.CATLSCertificateFile == "" || cfg.CATLSKeyFile == "" || cfg.CACertificateFile == "" || cfg.CARootFile == "" || cfg.CASignerFile == "" || cfg.CAIdentityFile == "" || cfg.DatabaseFile == "" {
		return errors.New("CA requires explicit private listener, TLS, database and issuer configuration")
	}
	statusAddr, e := netip.ParseAddrPort(cfg.CAStatusListen)
	if e != nil || statusAddr.Port() == 0 || (!statusAddr.Addr().IsPrivate() && !statusAddr.Addr().IsLoopback()) || cfg.CAStatusOrigin == "" || cfg.CARootCRLFile == "" {
		return errors.New("CA requires separate private HTTP status listener and public root CRL")
	}
	return nil
}
func runCA(ctx context.Context, cfg bootstrap.Config) error {
	if e := validateCAConfig(cfg); e != nil {
		return e
	}
	issuer, e := pkicrypto.LoadIssuer(pkicrypto.Config{CertificateFile: cfg.CACertificateFile, RootFile: cfg.CARootFile, SignerFile: cfg.CASignerFile, IdentityFile: cfg.CAIdentityFile})
	if e != nil {
		return e
	}
	pair, e := tls.LoadX509KeyPair(cfg.CATLSCertificateFile, cfg.CATLSKeyFile)
	if e != nil {
		return errors.New("CA bootstrap TLS material unavailable")
	}
	leaf, e := x509.ParseCertificate(pair.Certificate[0])
	if e != nil || leaf.IsCA || leaf.VerifyHostname(cfg.CAHostname) != nil || time.Now().Before(leaf.NotBefore) || !time.Now().Before(leaf.NotAfter) {
		return errors.New("invalid CA bootstrap TLS certificate")
	}
	serverAuth := false
	for _, eku := range leaf.ExtKeyUsage {
		if eku == x509.ExtKeyUsageServerAuth {
			serverAuth = true
		}
	}
	if !serverAuth {
		return errors.New("CA bootstrap TLS requires serverAuth")
	}
	db, e := postgres.Open(ctx, cfg)
	if e != nil {
		return e
	}
	defer db.Close()
	addr, _ := netip.ParseAddrPort(cfg.CAListen)
	deny := append([]string(nil), cfg.CAValidationDenyNetworks...)
	deny = append(deny, netip.PrefixFrom(addr.Addr(), addr.Addr().BitLen()).String())
	statusAddr, _ := netip.ParseAddrPort(cfg.CAStatusListen)
	deny = append(deny, netip.PrefixFrom(statusAddr.Addr(), statusAddr.Addr().BitLen()).String())
	server, e := pki.NewServer(pki.Config{ServerNames: cfg.CAServerNames, ClientNames: cfg.CAClientNames, Origin: cfg.CAOrigin, IdentityFile: cfg.CAIdentityFile, StatusOrigin: cfg.CAStatusOrigin, RootCRLFile: cfg.CARootCRLFile, RootOCSPCertificateFile: cfg.CARootOCSPCertificateFile, RootOCSPSignerFile: cfg.CARootOCSPSignerFile, ValidationNetworks: cfg.CAValidationNetworks, ValidationDenyNetworks: deny}, db, issuer)
	if e != nil {
		return e
	}
	startup, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	if e = pki.CheckCARole(startup, db); e != nil {
		return e
	}
	if e = pki.RegisterIssuer(startup, db, issuer); e != nil {
		return errors.New("CA issuer registration failed")
	}
	if e = server.RegisterStatus(startup, db); e != nil {
		return e
	}
	// Validate offline status before exposing either protocol listener.
	if e = (pkicrypto.RootCRLReader{Root: issuer.Chain[0], Path: cfg.CARootCRLFile}).CheckIssuer(ctx, issuer.Certificate); e != nil {
		return e
	}
	tlsCfg := pki.BootstrapTLSConfig()
	tlsCfg.Certificates = []tls.Certificate{pair}
	listener, e := (&net.ListenConfig{}).Listen(ctx, "tcp", cfg.CAListen)
	if e != nil {
		return errors.New("CA private listener unavailable")
	}
	defer listener.Close()
	statusListener, e := (&net.ListenConfig{}).Listen(ctx, "tcp", cfg.CAStatusListen)
	if e != nil {
		return errors.New("CA private status listener unavailable")
	}
	defer statusListener.Close()
	makeServer := func(handler http.Handler) *http.Server {
		return &http.Server{Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16384}
	}
	srv, statusSrv := makeServer(server), makeServer(server.StatusHandler())
	done := make(chan error, 2)
	go func() { done <- srv.Serve(tls.NewListener(listener, tlsCfg)) }()
	go func() { done <- statusSrv.Serve(statusListener) }()
	select {
	case e = <-done:
	case <-ctx.Done():
		e = nil
	}
	shutdown, cancelShutdown := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancelShutdown()
	for _, s := range []*http.Server{srv, statusSrv} {
		if err := s.Shutdown(shutdown); err != nil {
			_ = s.Close()
			if e == nil {
				e = err
			}
		}
	}
	if errors.Is(e, http.ErrServerClosed) {
		return nil
	}
	return e
}
