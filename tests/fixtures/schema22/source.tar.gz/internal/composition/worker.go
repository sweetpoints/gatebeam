package composition

import (
	"context"
	"errors"
	"gatebeam/internal/modules/deployment/application/health"
	"gatebeam/internal/modules/deployment/infrastructure/dns"
	deploymentpg "gatebeam/internal/modules/deployment/infrastructure/postgres"
	"gatebeam/internal/modules/deployment/infrastructure/probe"
	"gatebeam/internal/platform/bootstrap"
	"gatebeam/internal/platform/jobs"
	"gatebeam/internal/platform/postgres"
	"net/netip"
	"os"
	"time"
)

// runtimeProtected is process-owned configuration, never a request override.
func runtimeProtected(cfg bootstrap.Config) ([]netip.Prefix, error) {
	address := cfg.ManagementAPIAddress
	if address == "" {
		address = cfg.APIListen
	}
	api, e := netip.ParseAddrPort(address)
	if e != nil || !api.Addr().IsPrivate() || api.Port() != 8080 {
		return nil, errors.New("invalid private management API address")
	}
	out := []netip.Prefix{netip.PrefixFrom(api.Addr(), api.Addr().BitLen())}
	if cfg.APIPrivateNetwork != "" {
		p, e := netip.ParsePrefix(cfg.APIPrivateNetwork)
		if e != nil {
			return nil, errors.New("invalid private API network")
		}
		out = append(out, p)
	}
	for _, v := range cfg.ProtectedNetworks {
		p, e := netip.ParsePrefix(v)
		if e != nil {
			return nil, errors.New("invalid protected network")
		}
		out = append(out, p)
	}
	return out, nil
}
func runWorker(ctx context.Context, cfg bootstrap.Config) error {
	if cfg.DatabaseFile == "" {
		return errors.New("worker database reference required")
	}
	protected, e := runtimeProtected(cfg)
	if e != nil {
		return e
	}
	boot, cancel := context.WithTimeout(ctx, 10*time.Second)
	p, e := postgres.Open(boot, cfg)
	cancel()
	if e != nil {
		return e
	}
	defer p.Close()
	repo := deploymentpg.NewRuntime(p, jobs.New(p), protected)
	service := health.New(repo, dns.Targets{Protected: protected}, probe.HTTP{})
	materialCtx, stopMaterials := context.WithCancel(ctx)
	materialErrors := make(chan error, 1)
	materialStopped := false
	defer func() {
		stopMaterials()
		if !materialStopped {
			select {
			case <-materialErrors:
			case <-time.After(10 * time.Second):
			}
		}
	}()
	go func() { materialErrors <- runMaterialWorker(materialCtx, cfg, p, repo) }()
	logCtx, stopLogs := context.WithCancel(ctx)
	logErrors := make(chan error, 1)
	defer func() {
		stopLogs()
		select {
		case <-logErrors:
		case <-time.After(10 * time.Second):
		}
	}()
	go func() { logErrors <- runLogWorker(logCtx, cfg, p) }()
	historyCtx, stopHistory := context.WithCancel(ctx)
	historyDone := make(chan error, 2)
	historyStopped := 0
	go func() { historyDone <- runHistoryWorker(historyCtx, cfg, p) }()
	go func() { historyDone <- runArchiveWorker(historyCtx, cfg, p) }()
	defer func() {
		stopHistory()
		for range 2 - historyStopped {
			select {
			case <-historyDone:
			case <-time.After(10 * time.Second):
			}
		}
	}()

	notificationCtx, stopNotification := context.WithCancel(ctx)
	notificationDone := make(chan error, 1)
	notificationStopped := false
	go func() { notificationDone <- runNotificationWorker(notificationCtx, cfg, p) }()
	defer func() {
		stopNotification()
		if !notificationStopped {
			select {
			case <-notificationDone:
			case <-time.After(10 * time.Second):
			}
		}
	}()
	backupCtx, stopBackup := context.WithCancel(ctx)
	backupDone := make(chan error, 1)
	backupStopped := false
	go func() { backupDone <- runBackupWorker(backupCtx, cfg, p) }()
	defer func() {
		stopBackup()
		if !backupStopped {
			select {
			case <-backupDone:
			case <-time.After(10 * time.Second):
			}
		}
	}()
	tick := time.NewTicker(time.Second)
	defer tick.Stop()
	loop := newWorkerLoop(repo, service, newWorkerDiagnostics(os.Stderr), time.Now)
	for {
		select {
		case <-ctx.Done():
			return nil
		case e := <-backupDone:
			backupStopped = true
			return e
		case e := <-notificationDone:
			notificationStopped = true
			return e
		case e := <-historyDone:
			historyStopped++
			return e
		case e := <-materialErrors:
			materialStopped = true
			return e
		case <-tick.C:
			loop.step(ctx)
		}
	}
}
