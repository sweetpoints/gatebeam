package composition

import (
	"context"
	"gatebeam/internal/platform/bootstrap"
	"testing"
)

func TestOperatorBooleanCannotDeclareManagementTLSReady(t *testing.T) {
	e := verifyManagement(context.Background(), bootstrap.Config{HTTPSGatewayReady: true, APIOrigin: "https://management.test"})
	if e == nil {
		t.Fatal("operator flag accepted without measured serving TLS")
	}
}
func TestAPIOnlyBindsDeclaredPrivateManagementAddress(t *testing.T) {
	for _, address := range []string{"0.0.0.0:8080", "8.8.8.8:8080", "172.30.0.4:8080"} {
		if e := validateAPIListen(bootstrap.Config{APIListen: address, APIPrivateNetwork: "172.30.0.0/30"}); e == nil {
			t.Fatalf("unrestricted API bind accepted: %s", address)
		}
	}
	if e := validateAPIListen(bootstrap.Config{APIListen: "172.30.0.3:8080", APIPrivateNetwork: "172.30.0.0/29"}); e != nil {
		t.Fatal(e)
	}
	if e := validateAPIListen(bootstrap.Config{APIListen: "127.0.0.1:8080"}); e != nil {
		t.Fatal(e)
	}
}
