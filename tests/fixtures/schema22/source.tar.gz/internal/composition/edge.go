package composition

import (
	"context"
	"encoding/json"
	"errors"
	"gatebeam/internal/integration/certificateaccess"
	"gatebeam/internal/integration/certificatematerials"
	"gatebeam/internal/integration/ingressaccess"
	"gatebeam/internal/integration/publication"
	"gatebeam/internal/modules/certificates"
	"gatebeam/internal/modules/deployment"
	edge "gatebeam/internal/modules/deployment/application/runtime"
	"gatebeam/internal/modules/deployment/domain"
	runtimebootstrap "gatebeam/internal/modules/deployment/infrastructure/bootstrap"
	"gatebeam/internal/modules/deployment/infrastructure/filesystem"
	"gatebeam/internal/modules/deployment/infrastructure/identifiers"
	"gatebeam/internal/modules/deployment/infrastructure/nginx"
	deploymentpg "gatebeam/internal/modules/deployment/infrastructure/postgres"
	"gatebeam/internal/modules/deployment/infrastructure/probe"
	"gatebeam/internal/modules/identity"
	"gatebeam/internal/modules/ingress"
	"gatebeam/internal/modules/pki"
	"gatebeam/internal/platform/audit"
	"gatebeam/internal/platform/bootstrap"
	"gatebeam/internal/platform/jobs"
	"gatebeam/internal/platform/postgres"
	"net/netip"
	"path/filepath"
	"time"
)

func runEdge(ctx context.Context, cfg bootstrap.Config) error {
	if cfg.EdgeRoot == "" || cfg.DatabaseFile == "" || cfg.ManagementDomain == "" || cfg.ManagementCertificateFile == "" || cfg.ManagementKeyFile == "" || cfg.ManagementTrustFile == "" {
		return errors.New("edge bootstrap configuration incomplete")
	}
	api, e := netip.ParseAddrPort(cfg.ManagementAPIAddress)
	if e != nil || !api.Addr().IsPrivate() || api.Port() != 8080 {
		return errors.New("invalid private management API address")
	}
	protected := []netip.Prefix{netip.PrefixFrom(api.Addr(), api.Addr().BitLen())}
	for _, v := range cfg.ProtectedNetworks {
		p, e := netip.ParsePrefix(v)
		if e != nil {
			return errors.New("invalid protected network")
		}
		protected = append(protected, p)
	}
	disk, e := filesystem.New(cfg.EdgeRoot)
	if e != nil {
		return e
	}
	process, e := nginx.NewProcess("/usr/sbin/nginx", cfg.EdgeRoot)
	if e != nil {
		return e
	}
	boot, cancel := context.WithTimeout(ctx, 10*time.Second)
	pool, e := postgres.Open(boot, cfg)
	cancel()
	if e != nil {
		return e
	}
	defer pool.Close()
	catalog := &ingressaccess.Catalog{}
	access := identity.NewAccess(pool, catalog)
	sites := ingress.New(pool, ingressaccess.Authorizer{Identity: access})
	catalog.Ingress = sites
	store := jobs.New(pool)
	if cfg.CertificateProviderIdentityFile != "" {
		return errors.New("edge must not configure a provider identity")
	}
	materials := certificates.NewReader(pool)
	if cfg.CertificateIdentityFile != "" {
		materials, e = certificates.NewEdge(pool, certificateaccess.Graph{Ingress: sites}, cfg.CertificateIdentityFile, cfg.CertificateProviderRecipient)
		if e != nil {
			return e
		}
	}
	materials.SetLeafStatus(certificatematerials.LeafStatus{Owner: pki.NewMaterialStatus()})
	if e = certificates.ConfigureStatus(materials, cfg.CertificateStatusProfilesFile); e != nil {
		return e
	}
	coordinator := publication.New(postgres.NewRunner(pool), access, sites, certificatematerials.Adapter{Owner: materials}, deployment.New(), store, audit.New(), identifiers.Generator{})
	bindings := deploymentpg.NewRuntime(pool, store, protected)
	source := &runtimebootstrap.Source{ACMEWebRoot: cfg.ACMEWebRoot, Bindings: bindings, Materials: certificatematerials.Adapter{Owner: materials}, Cloudflare: bindings, Domain: cfg.ManagementDomain, CertificateFile: cfg.ManagementCertificateFile, KeyFile: cfg.ManagementKeyFile, TrustFile: cfg.ManagementTrustFile, APIAddress: api, LogDirectory: filepath.Join(cfg.EdgeRoot, "logs"), ProtectedNetworks: protected}
	compiler := nginx.Compiler{}
	supervisor := func(j jobs.Job) (*edge.Supervisor, *publication.Execution) {
		execution := publication.NewExecution(coordinator, store, j, source, compiler)
		return edge.NewSupervisor(process, disk, disk, compiler, execution, edge.RouteVerifier{Probe: probe.HTTP{}, Evidence: bindings}), execution
	}
	recovery, _ := supervisor(jobs.Job{})
	defer func() {
		stop, cancel := context.WithTimeout(context.Background(), 6*time.Second)
		defer cancel()
		_ = process.Stop(stop)
	}()
	// Startup resolves current bindings before starting any child. At runtime DB
	// failures only defer control operations: they never terminate serving Nginx.
	if _, e = recovery.Recover(ctx); e != nil {
		return e
	}
	tick := time.NewTicker(time.Second)
	defer tick.Stop()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-tick.C:
		}
		j, e := disk.Load(ctx)
		if e != nil {
			return e
		}
		if j.ReceiptPending || process.PID() == 0 {
			if _, e = recovery.Recover(ctx); e != nil {
				continue
			}
		}
		claim, cancel := context.WithTimeout(ctx, 3*time.Second)
		job, e := store.ClaimKinds(claim, "local-edge", time.Minute, []string{"deployment.apply", "deployment.generation", "deployment.rotate_logs"})
		cancel()
		if e != nil {
			continue
		}
		s, execution := supervisor(job)
		switch job.Kind {
		case "deployment.apply":
			var payload struct {
				ReleaseID string `json:"release_id"`
			}
			if json.Unmarshal(job.Payload, &payload) != nil || payload.ReleaseID == "" {
				continue
			}
			result, e := s.Apply(ctx, payload.ReleaseID)
			if e != nil {
				_ = execution.RecordFailure(ctx, payload.ReleaseID, result)
			}
		case "deployment.generation":
			var payload struct {
				Kind string `json:"kind"`
			}
			if json.Unmarshal(job.Payload, &payload) != nil || !domain.DerivedKind(payload.Kind) {
				continue
			}
			_, _ = s.ApplyDerived(ctx, payload.Kind)
		case "deployment.rotate_logs":
			if e = s.RotateLogs(ctx); e == nil {
				done, cancel := context.WithTimeout(ctx, 3*time.Second)
				_ = store.Complete(done, job.ID, job.LeaseToken)
				cancel()
			}
		}
	}
}
