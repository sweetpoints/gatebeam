//go:build integration

package composition

import (
	"context"
	"gatebeam/internal/platform/bootstrap"
	"github.com/jackc/pgx/v5/pgxpool"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestMigrateEmbeddedRuntime(t *testing.T) {
	dsn := os.Getenv("GATEBEAM_TEST_DATABASE_URL")
	if dsn == "" {
		t.Fatal("run scripts/check-db.sh: PostgreSQL DSN required")
	}
	path := filepath.Join(t.TempDir(), "database")
	if e := os.WriteFile(path, []byte(dsn), 0600); e != nil {
		t.Fatal(e)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	cfg := bootstrap.Config{Mode: "migrate", DatabaseFile: path}
	for range 2 {
		if e := Run(ctx, "migrate", cfg); e != nil {
			t.Fatal(e)
		}
	}
	p, e := pgxpool.New(ctx, dsn)
	if e != nil {
		t.Fatal("test pool unavailable")
	}
	defer p.Close()
	var n int
	if e = p.QueryRow(ctx, "SELECT count(*) FROM goose_db_version WHERE version_id=1 AND is_applied").Scan(&n); e != nil || n != 1 {
		t.Fatalf("migration version %d: %v", n, e)
	}
}
